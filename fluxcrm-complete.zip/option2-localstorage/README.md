# FluxCRM - localStorage Edition

This version includes **data persistence** using browser localStorage.

## 💾 Data Persistence Features

- **Auto-save**: Data automatically saves every 30 seconds
- **Auto-load**: Previous session data restored on page load
- **Export**: Download your data as JSON backup
- **Import**: Restore from backup file
- **Reset**: Clear all data and restore defaults

## 🚀 Usage

1. Open `index.html` in any modern browser
2. All changes are automatically saved to your browser
3. Use the **database icon** (top right) to manage data:
   - Export backup
   - Import backup
   - Reset data

## ⚠️ Important Notes

- **Browser-specific**: Data is stored per browser (Chrome data won't appear in Firefox)
- **Private mode**: localStorage may not work in Incognito/Private windows
- **Clearing cookies**: Will delete your CRM data
- **5MB limit**: localStorage has a ~5MB limit per domain

## 🔄 Backup Strategy

**Recommended**: Export a backup weekly:
1. Click the database icon (top right)
2. Click "Export Backup"
3. Save the JSON file to your computer
4. To restore: Click "Import Data" and select the file

## 🌐 Deployment

Deploy to any static hosting (GitHub Pages, Netlify, Vercel):
- Data persists per user per browser
- Each user has their own isolated data
- No server or database required

## 🆚 vs Server Edition

| Feature | localStorage | Server + Database |
|---------|-------------|-------------------|
| Multi-user | ❌ Per browser only | ✅ Yes |
| Data sharing | ❌ No | ✅ Yes |
| Mobile sync | ❌ No | ✅ Yes |
| Security | ⚠️ Browser level | ✅ Server level |
| Scalability | ⚠️ 5MB limit | ✅ Unlimited |
| Setup | ✅ Zero | ⚠️ Requires server |

For multi-user or production use, upgrade to Option 3 (Backend API) + Option 4 (Database).
