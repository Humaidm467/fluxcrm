const { Pool } = require('pg');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Database configuration
const DB_TYPE = process.env.DB_TYPE || 'sqlite'; // 'sqlite' or 'postgresql'

class Database {
    constructor() {
        this.db = null;
        this.type = DB_TYPE;
    }

    async connect() {
        if (this.type === 'postgresql') {
            // PostgreSQL connection
            this.db = new Pool({
                host: process.env.DB_HOST || 'localhost',
                port: process.env.DB_PORT || 5432,
                database: process.env.DB_NAME || 'fluxcrm',
                user: process.env.DB_USER || 'fluxcrm_user',
                password: process.env.DB_PASSWORD || 'password',
                ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false
            });
            console.log('✅ Connected to PostgreSQL');
        } else {
            // SQLite connection (default for development)
            const dbPath = path.join(__dirname, 'fluxcrm.db');
            this.db = new sqlite3.Database(dbPath, (err) => {
                if (err) {
                    console.error('SQLite connection error:', err);
                } else {
                    console.log('✅ Connected to SQLite:', dbPath);
                }
            });
        }
        return this.db;
    }

    async query(sql, params = []) {
        if (this.type === 'postgresql') {
            const result = await this.db.query(sql, params);
            return result.rows;
        } else {
            // SQLite uses callbacks, so we wrap in Promise
            return new Promise((resolve, reject) => {
                if (sql.trim().toLowerCase().startsWith('select')) {
                    this.db.all(sql, params, (err, rows) => {
                        if (err) reject(err);
                        else resolve(rows);
                    });
                } else {
                    this.db.run(sql, params, function(err) {
                        if (err) reject(err);
                        else resolve({ id: this.lastID, changes: this.changes });
                    });
                }
            });
        }
    }

    async initSchema() {
        const fs = require('fs');
        const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');

        if (this.type === 'sqlite') {
            // SQLite: execute statements one by one
            const statements = schema.split(';').filter(s => s.trim());
            for (const stmt of statements) {
                if (stmt.trim()) {
                    await this.query(stmt);
                }
            }
        } else {
            // PostgreSQL: can execute all at once
            await this.db.query(schema);
        }
        console.log('✅ Database schema initialized');
    }

    async seed() {
        const fs = require('fs');
        const seed = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf8');

        if (this.type === 'sqlite') {
            const statements = seed.split(';').filter(s => s.trim());
            for (const stmt of statements) {
                if (stmt.trim()) {
                    await this.query(stmt);
                }
            }
        } else {
            await this.db.query(seed);
        }
        console.log('✅ Seed data loaded');
    }

    async close() {
        if (this.type === 'postgresql') {
            await this.db.end();
        } else {
            this.db.close();
        }
    }
}

module.exports = new Database();
