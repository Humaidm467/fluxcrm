# FluxCRM - Database Edition (SQLite + PostgreSQL)

Full production database support for FluxCRM with automatic schema management.

## 🗄️ Database Options

### SQLite (Default - Development)
- **File-based**: No server needed
- **Zero configuration**: Works out of the box
- **Portable**: Single `.db` file
- **Limit**: Not for high concurrency

### PostgreSQL (Production)
- **Enterprise-grade**: Handles high concurrency
- **ACID compliant**: Transaction safety
- **Scalable**: Supports millions of records
- **Hosted options**: AWS RDS, Supabase, Railway, Render

## 🚀 Quick Start

### SQLite (Default)
```bash
cd option4-database

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Start server (auto-creates database)
npm start

# Database file: fluxcrm.db (created automatically)
```

### PostgreSQL
```bash
# Install PostgreSQL locally or use cloud provider
# Create database and user

# Update .env
DB_TYPE=postgresql
DB_HOST=your-host
DB_PORT=5432
DB_NAME=fluxcrm
DB_USER=your-user
DB_PASSWORD=your-password

# Start server
npm start
```

## 📊 Database Schema

### Tables Created Automatically

| Table | Purpose |
|-------|---------|
| `users` | System users with roles |
| `leads` | Prospect leads |
| `contacts` | Customer contacts |
| `opportunities` | Sales deals |
| `activities` | Tasks, calls, meetings |
| `quotes` | Quotations |
| `quote_items` | Quote line items |
| `orders` | Sales orders |
| `products` | Product catalog |
| `documents` | File metadata |
| `audit_logs` | Security audit trail |

### Indexes
- Optimized indexes on foreign keys, status fields, and dates
- Automatic query performance tuning

## 🔧 Database Commands

```bash
# Initialize schema only
npm run db:init

# Load seed data
npm run db:seed

# Reset everything (SQLite only)
npm run db:reset
```

## 🔄 Migration Strategy

For production schema changes:

```sql
-- migrations/v1.1.0_add_phone_to_contacts.sql
ALTER TABLE contacts ADD COLUMN mobile_phone VARCHAR(50);
```

Run migrations manually or use a migration tool like:
- `node-pg-migrate` (PostgreSQL)
- `sqlite-migrate` (SQLite)

## 🌐 Cloud Database Options

### Supabase (Recommended Free Tier)
1. Create account at [supabase.com](https://supabase.com)
2. New project → Database settings
3. Copy connection string
4. Set in `.env`:
```
DB_TYPE=postgresql
DB_HOST=db.xxx.supabase.co
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=your-password
DB_SSL=true
```

### Railway
```bash
railway add --database postgres
# Railway provides connection string automatically
```

### AWS RDS
- Create PostgreSQL instance
- Configure security group
- Use connection endpoint in `.env`

## 📈 Performance Tuning

### SQLite
```sql
-- Enable WAL mode for better concurrency
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
```

### PostgreSQL
```sql
-- Create additional indexes for common queries
CREATE INDEX CONCURRENTLY idx_opportunities_value ON opportunities(value);
CREATE INDEX CONCURRENTLY idx_activities_type ON activities(type);
```

## 🔒 Backup Strategy

### SQLite
```bash
# Simple file copy
cp fluxcrm.db fluxcrm-backup-$(date +%Y%m%d).db

# Or use SQLite command
sqlite3 fluxcrm.db ".backup 'backup.db'"
```

### PostgreSQL
```bash
# pg_dump
pg_dump -h localhost -U fluxcrm_user fluxcrm > backup.sql

# Restore
psql -h localhost -U fluxcrm_user fluxcrm < backup.sql
```

## 📊 Database Size Estimates

| Records | SQLite Size | PostgreSQL Size |
|---------|-------------|-----------------|
| 1,000 | ~2 MB | ~5 MB |
| 10,000 | ~15 MB | ~30 MB |
| 100,000 | ~120 MB | ~250 MB |
| 1,000,000 | ~1 GB | ~2 GB |

## 🆚 SQLite vs PostgreSQL

| Feature | SQLite | PostgreSQL |
|---------|--------|------------|
| Setup | Zero | Requires server |
| Concurrency | Limited | Excellent |
| Data types | Basic | Rich |
| JSON support | Basic | Native JSONB |
| Full-text search | Basic | Advanced |
| Replication | No | Yes |
| Best for | Single user, testing | Production, teams |

## 🚀 Deployment

Deploy the entire Option 3 + 4 stack:

```bash
# 1. Deploy database (PostgreSQL on Railway/Render/AWS)
# 2. Set environment variables
# 3. Deploy Node.js backend
# 4. Deploy frontend (static hosting)

# Example: Railway deployment
railway add --database postgres
railway up
```

## 📄 License

MIT License
