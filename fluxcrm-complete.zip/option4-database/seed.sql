-- Seed data for FluxCRM
-- Run this after creating tables

-- Insert demo users
INSERT INTO users (name, email, password_hash, role, team, quota) VALUES
('Alex Morgan', 'alex.morgan@fluxcrm.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.VTtYA.qGZvKG6', 'Sales Director', 'Enterprise', 500000),
('Jordan Lee', 'jordan.lee@fluxcrm.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.VTtYA.qGZvKG6', 'Account Executive', 'Mid-Market', 300000),
('Sam Taylor', 'sam.taylor@fluxcrm.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.VTtYA.qGZvKG6', 'Sales Development', 'Inbound', 150000),
('Casey Rivera', 'casey.rivera@fluxcrm.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.VTtYA.qGZvKG6', 'Sales Engineer', 'Enterprise', 0);

-- Insert demo products
INSERT INTO products (name, sku, category, price, unit) VALUES
('FluxCRM Professional', 'FLX-PRO-001', 'Software License', 5000, 'user/year'),
('FluxCRM Enterprise', 'FLX-ENT-001', 'Software License', 12000, 'user/year'),
('Implementation Services', 'FLX-IMP-001', 'Services', 25000, 'project'),
('Training Package - Basic', 'FLX-TRB-001', 'Services', 5000, 'session'),
('Training Package - Advanced', 'FLX-TRA-001', 'Services', 12000, 'session'),
('API Integration Module', 'FLX-API-001', 'Add-on', 8000, 'connector');

-- Insert demo leads
INSERT INTO leads (name, company, email, phone, source, score, status, assigned_to, notes) VALUES
('Sarah Chen', 'TechVentures Inc', 's.chen@techventures.com', '+1 (555) 234-5678', 'Website', 92, 'Hot', 1, 'Interested in enterprise plan. Budget approved.'),
('Marcus Johnson', 'Global Dynamics', 'm.johnson@globaldyn.com', '+1 (555) 876-1234', 'LinkedIn', 78, 'Warm', 1, 'CTO referral. Evaluating 3 vendors.'),
('Elena Rodriguez', 'InnovateSoft', 'e.rodriguez@innovatesoft.io', '+1 (555) 456-7890', 'Trade Show', 85, 'Hot', 2, 'Met at SaaS Summit 2026. Immediate need.'),
('David Park', 'DataFlow Systems', 'd.park@dataflow.sys', '+1 (555) 321-6547', 'Email Campaign', 45, 'Cold', 3, 'Downloaded whitepaper. No response yet.'),
('Amanda Foster', 'CloudNine Solutions', 'a.foster@cloudnine.io', '+1 (555) 987-4321', 'Referral', 88, 'Warm', 1, 'Existing customer referral. High intent.'),
('Robert Kim', 'Quantum Leap', 'r.kim@quantumleap.tech', '+1 (555) 654-3210', 'Google Ads', 62, 'Warm', 2, 'Clicked ad 3 times. Pricing page visited.'),
('Lisa Thompson', 'Meridian Corp', 'l.thompson@meridian.co', '+1 (555) 789-0123', 'Cold Call', 35, 'Cold', 3, 'Gatekeeper blocked. Need alternative contact.'),
('James Wilson', 'Atlas Industries', 'j.wilson@atlas.ind', '+1 (555) 234-8901', 'Website', 95, 'Hot', 1, 'Demo completed. Ready to sign. Legal review pending.');

-- Insert demo contacts
INSERT INTO contacts (name, company, role, email, phone, type, last_contact, lifetime_value) VALUES
('Sarah Chen', 'TechVentures Inc', 'VP of Engineering', 's.chen@techventures.com', '+1 (555) 234-5678', 'Prospect', '2026-05-31', 125000),
('Marcus Johnson', 'Global Dynamics', 'CTO', 'm.johnson@globaldyn.com', '+1 (555) 876-1234', 'Prospect', '2026-05-30', 85000),
('Elena Rodriguez', 'InnovateSoft', 'CEO', 'e.rodriguez@innovatesoft.io', '+1 (555) 456-7890', 'Prospect', '2026-05-29', 200000),
('Michael Brooks', 'Stellar Enterprises', 'Procurement Manager', 'm.brooks@stellar.com', '+1 (555) 111-2222', 'Customer', '2026-05-28', 450000),
('Jennifer Walsh', 'Nexus Group', 'Director of IT', 'j.walsh@nexus.group', '+1 (555) 333-4444', 'Customer', '2026-05-27', 320000),
('Carlos Mendez', 'Horizon Tech', 'Sales Manager', 'c.mendez@horizon.tech', '+1 (555) 555-6666', 'Partner', '2026-05-26', 0);
