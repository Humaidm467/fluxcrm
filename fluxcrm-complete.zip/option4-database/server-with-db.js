const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const db = require('./db-config');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware setup
app.use(helmet());
app.use(cors({
    origin: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

const limiter = rateLimit({
    windowMs: (parseInt(process.env.RATE_LIMIT_WINDOW) || 15) * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 100
});
app.use('/api/', limiter);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined'));
app.use(compression());
app.use(express.static('public'));

// Authentication middleware
const authenticate = async (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access denied. No token provided.' });

    try {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
        req.user = decoded;
        next();
    } catch (err) {
        res.status(400).json({ error: 'Invalid token.' });
    }
};

const authorize = (roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Access denied.' });
        }
        next();
    };
};

// Initialize database and start server
async function startServer() {
    try {
        await db.connect();
        await db.initSchema();

        // Check if seed data exists
        const users = await db.query('SELECT COUNT(*) as count FROM users');
        const count = users[0].count || users[0]['COUNT(*)'];

        if (count === 0) {
            await db.seed();
        }

        // ==================== API ROUTES ====================

        // Health check
        app.get('/api/health', async (req, res) => {
            res.json({ 
                status: 'OK', 
                database: db.type,
                timestamp: new Date().toISOString(), 
                version: '1.0.0' 
            });
        });

        // Auth
        app.post('/api/auth/login', async (req, res) => {
            const jwt = require('jsonwebtoken');
            const { email, password } = req.body;

            const users = await db.query('SELECT * FROM users WHERE email = ? AND active = 1', [email]);
            const user = users[0];

            if (!user) return res.status(400).json({ error: 'Invalid credentials' });

            // Demo mode: skip password check
            const token = jwt.sign(
                { id: user.id, email: user.email, role: user.role },
                process.env.JWT_SECRET || 'fallback-secret',
                { expiresIn: process.env.JWT_EXPIRE || '7d' }
            );

            res.json({ 
                token, 
                user: { 
                    id: user.id, 
                    name: user.name, 
                    email: user.email, 
                    role: user.role 
                } 
            });
        });

        // Leads
        app.get('/api/leads', authenticate, async (req, res) => {
            const leads = await db.query('SELECT * FROM leads ORDER BY created_at DESC');
            res.json(leads);
        });

        app.post('/api/leads', authenticate, async (req, res) => {
            const { name, company, email, phone, source, score, status, assigned_to, notes } = req.body;
            const result = await db.query(
                'INSERT INTO leads (name, company, email, phone, source, score, status, assigned_to, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [name, company, email, phone, source, score, status, assigned_to, notes]
            );
            res.status(201).json({ id: result.id || result.insertId, ...req.body });
        });

        app.put('/api/leads/:id', authenticate, async (req, res) => {
            const fields = Object.keys(req.body).map(k => `${k} = ?`).join(', ');
            const values = [...Object.values(req.body), req.params.id];
            await db.query(`UPDATE leads SET ${fields} WHERE id = ?`, values);
            res.json({ id: req.params.id, ...req.body });
        });

        app.delete('/api/leads/:id', authenticate, async (req, res) => {
            await db.query('DELETE FROM leads WHERE id = ?', [req.params.id]);
            res.json({ message: 'Lead deleted' });
        });

        // Contacts
        app.get('/api/contacts', authenticate, async (req, res) => {
            const contacts = await db.query('SELECT * FROM contacts ORDER BY created_at DESC');
            res.json(contacts);
        });

        app.post('/api/contacts', authenticate, async (req, res) => {
            const { name, company, role, email, phone, type } = req.body;
            const result = await db.query(
                'INSERT INTO contacts (name, company, role, email, phone, type) VALUES (?, ?, ?, ?, ?, ?)',
                [name, company, role, email, phone, type]
            );
            res.status(201).json({ id: result.id || result.insertId, ...req.body });
        });

        // Opportunities
        app.get('/api/opportunities', authenticate, async (req, res) => {
            const opps = await db.query('SELECT * FROM opportunities ORDER BY created_at DESC');
            res.json(opps);
        });

        app.post('/api/opportunities', authenticate, async (req, res) => {
            const { name, company, value, stage, probability, expected_close, assigned_to, priority } = req.body;
            const result = await db.query(
                'INSERT INTO opportunities (name, company, value, stage, probability, expected_close, assigned_to, priority) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [name, company, value, stage, probability, expected_close, assigned_to, priority]
            );
            res.status(201).json({ id: result.id || result.insertId, ...req.body });
        });

        app.put('/api/opportunities/:id', authenticate, async (req, res) => {
            const fields = Object.keys(req.body).map(k => `${k} = ?`).join(', ');
            const values = [...Object.values(req.body), req.params.id];
            await db.query(`UPDATE opportunities SET ${fields} WHERE id = ?`, values);
            res.json({ id: req.params.id, ...req.body });
        });

        // Activities
        app.get('/api/activities', authenticate, async (req, res) => {
            const activities = await db.query('SELECT * FROM activities ORDER BY due_date ASC');
            res.json(activities);
        });

        app.post('/api/activities', authenticate, async (req, res) => {
            const { type, title, contact_id, due_date, status, priority, notes } = req.body;
            const result = await db.query(
                'INSERT INTO activities (type, title, contact_id, due_date, status, priority, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [type, title, contact_id, due_date, status, priority, notes, req.user.id]
            );
            res.status(201).json({ id: result.id || result.insertId, ...req.body });
        });

        // Quotes
        app.get('/api/quotes', authenticate, async (req, res) => {
            const quotes = await db.query('SELECT * FROM quotes ORDER BY created_at DESC');
            res.json(quotes);
        });

        app.post('/api/quotes', authenticate, async (req, res) => {
            const { id, customer, contact_id, expiry_date, total, status, discount } = req.body;
            await db.query(
                'INSERT INTO quotes (id, customer, contact_id, expiry_date, total, status, discount, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [id, customer, contact_id, expiry_date, total, status, discount, req.user.id]
            );
            res.status(201).json(req.body);
        });

        // Orders
        app.get('/api/orders', authenticate, async (req, res) => {
            const orders = await db.query('SELECT * FROM orders ORDER BY created_at DESC');
            res.json(orders);
        });

        app.post('/api/orders', authenticate, async (req, res) => {
            const { id, customer, contact_id, total, status, payment_terms } = req.body;
            await db.query(
                'INSERT INTO orders (id, customer, contact_id, total, status, payment_terms, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [id, customer, contact_id, total, status, payment_terms, req.user.id]
            );
            res.status(201).json(req.body);
        });

        // Products
        app.get('/api/products', authenticate, async (req, res) => {
            const products = await db.query('SELECT * FROM products WHERE active = 1 ORDER BY name');
            res.json(products);
        });

        app.post('/api/products', authenticate, authorize(['Sales Director', 'Admin']), async (req, res) => {
            const { name, sku, category, price, unit } = req.body;
            const result = await db.query(
                'INSERT INTO products (name, sku, category, price, unit) VALUES (?, ?, ?, ?, ?)',
                [name, sku, category, price, unit]
            );
            res.status(201).json({ id: result.id || result.insertId, ...req.body });
        });

        // Users
        app.get('/api/users', authenticate, authorize(['Sales Director', 'Admin']), async (req, res) => {
            const users = await db.query('SELECT id, name, email, role, team, active FROM users');
            res.json(users);
        });

        // Dashboard
        app.get('/api/dashboard', authenticate, async (req, res) => {
            const totalPipeline = await db.query('SELECT COALESCE(SUM(value), 0) as total FROM opportunities');
            const weightedPipeline = await db.query('SELECT COALESCE(SUM(value * probability / 100), 0) as total FROM opportunities');
            const closedWon = await db.query("SELECT COALESCE(SUM(value), 0) as total FROM opportunities WHERE stage = 'Closed Won'");
            const openDeals = await db.query("SELECT COUNT(*) as count FROM opportunities WHERE stage != 'Closed Won'");
            const totalLeads = await db.query('SELECT COUNT(*) as count FROM leads');

            res.json({
                totalPipeline: totalPipeline[0].total || totalPipeline[0]['COALESCE(SUM(value), 0)'],
                weightedPipeline: weightedPipeline[0].total || weightedPipeline[0]['COALESCE(SUM(value * probability / 100), 0)'],
                closedWon: closedWon[0].total || closedWon[0]["COALESCE(SUM(value), 0)"],
                openDeals: openDeals[0].count || openDeals[0]['COUNT(*)'],
                totalLeads: totalLeads[0].count || totalLeads[0]['COUNT(*)']
            });
        });

        // Error handling
        app.use((err, req, res, next) => {
            console.error(err.stack);
            res.status(500).json({ error: 'Something went wrong!' });
        });

        app.use((req, res) => {
            res.status(404).json({ error: 'Route not found' });
        });

        app.listen(PORT, () => {
            console.log(`🚀 FluxCRM Server running on http://localhost:${PORT}`);
            console.log(`📊 Database: ${db.type}`);
            console.log(`🔒 Environment: ${process.env.NODE_ENV || 'development'}`);
        });

    } catch (err) {
        console.error('Failed to start server:', err);
        process.exit(1);
    }
}

startServer();

module.exports = app;
