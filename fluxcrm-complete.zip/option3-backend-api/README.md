# FluxCRM - Node.js/Express Backend API

Production-ready REST API for the FluxCRM Sales Management System.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ installed
- npm or yarn

### Installation

```bash
# Navigate to backend directory
cd option3-backend-api

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env with your settings (especially JWT_SECRET)
nano .env

# Start development server
npm run dev

# Or start production server
npm start
```

### Default Login (Demo)
```
Email: alex@fluxcrm.com
Password: password (any password works in demo mode)
```

## 📡 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login and get JWT token |
| GET | `/api/auth/me` | Get current user info |

### Leads
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/leads` | List all leads |
| POST | `/api/leads` | Create new lead |
| PUT | `/api/leads/:id` | Update lead |
| DELETE | `/api/leads/:id` | Delete lead |

### Contacts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/contacts` | List all contacts |
| POST | `/api/contacts` | Create new contact |

### Opportunities
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/opportunities` | List all opportunities |
| POST | `/api/opportunities` | Create new opportunity |
| PUT | `/api/opportunities/:id` | Update opportunity |

### Activities
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/activities` | List all activities |
| POST | `/api/activities` | Create new activity |

### Quotes
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/quotes` | List all quotes |
| POST | `/api/quotes` | Create new quote |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/orders` | List all orders |
| POST | `/api/orders` | Create new order |

### Products
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/products` | List all products | Any |
| POST | `/api/products` | Create product | Admin/Director only |

### Users (Admin)
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/users` | List all users | Admin/Director only |

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard` | Get dashboard statistics |

## 🔒 Authentication

All API endpoints (except `/api/health`) require JWT authentication:

```bash
# Get token
curl -X POST http://localhost:3000/api/auth/login   -H "Content-Type: application/json"   -d '{"email":"alex@fluxcrm.com","password":"password"}'

# Use token in subsequent requests
curl http://localhost:3000/api/leads   -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## 🛡️ Security Features

- **Helmet.js**: Secure HTTP headers
- **CORS**: Configurable cross-origin policies
- **Rate Limiting**: 100 requests per 15 minutes per IP
- **JWT Authentication**: Stateless token-based auth
- **RBAC**: Role-based access control (Sales Director, Account Executive, etc.)
- **Input Validation**: Express-validator ready
- **Compression**: Gzip response compression

## 📦 Deployment

### Deploy to Railway (Recommended)
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

### Deploy to Render
1. Create account at [render.com](https://render.com)
2. Create new Web Service
3. Connect your GitHub repo
4. Set environment variables
5. Deploy

### Deploy to Heroku
```bash
# Install Heroku CLI
heroku create fluxcrm-api
heroku config:set JWT_SECRET=your-secret-key
heroku config:set NODE_ENV=production
git push heroku main
```

## 🔄 Next Steps

1. **Add Database**: Replace in-memory store with PostgreSQL (Option 4)
2. **Add Email Service**: Integrate SendGrid/SES for notifications
3. **Add WebSockets**: Real-time updates with Socket.io
4. **Add File Storage**: AWS S3 for document uploads
5. **Add Testing**: Jest test suite

## 📄 License

MIT License
