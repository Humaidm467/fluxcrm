// FluxCRM API Client
// Connects the frontend to the Node.js/Express backend

const API_BASE_URL = window.location.origin.includes('localhost') 
    ? 'http://localhost:3000/api' 
    : '/api';

class FluxCRMAPI {
    constructor() {
        this.token = localStorage.getItem('fluxcrm_token');
        this.baseURL = API_BASE_URL;
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...(this.token ? { 'Authorization': `Bearer ${this.token}` } : {})
            },
            ...options
        };

        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(url, config);
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || `HTTP ${response.status}`);
            }
            return await response.json();
        } catch (err) {
            console.error('API Error:', err);
            throw err;
        }
    }

    // Auth
    async login(email, password) {
        const data = await this.request('/auth/login', {
            method: 'POST',
            body: { email, password }
        });
        this.token = data.token;
        localStorage.setItem('fluxcrm_token', data.token);
        return data;
    }

    async getMe() {
        return this.request('/auth/me');
    }

    logout() {
        this.token = null;
        localStorage.removeItem('fluxcrm_token');
    }

    // Leads
    getLeads() { return this.request('/leads'); }
    createLead(data) { return this.request('/leads', { method: 'POST', body: data }); }
    updateLead(id, data) { return this.request(`/leads/${id}`, { method: 'PUT', body: data }); }
    deleteLead(id) { return this.request(`/leads/${id}`, { method: 'DELETE' }); }

    // Contacts
    getContacts() { return this.request('/contacts'); }
    createContact(data) { return this.request('/contacts', { method: 'POST', body: data }); }

    // Opportunities
    getOpportunities() { return this.request('/opportunities'); }
    createOpportunity(data) { return this.request('/opportunities', { method: 'POST', body: data }); }
    updateOpportunity(id, data) { return this.request(`/opportunities/${id}`, { method: 'PUT', body: data }); }

    // Activities
    getActivities() { return this.request('/activities'); }
    createActivity(data) { return this.request('/activities', { method: 'POST', body: data }); }

    // Quotes
    getQuotes() { return this.request('/quotes'); }
    createQuote(data) { return this.request('/quotes', { method: 'POST', body: data }); }

    // Orders
    getOrders() { return this.request('/orders'); }
    createOrder(data) { return this.request('/orders', { method: 'POST', body: data }); }

    // Products
    getProducts() { return this.request('/products'); }
    createProduct(data) { return this.request('/products', { method: 'POST', body: data }); }

    // Dashboard
    getDashboard() { return this.request('/dashboard'); }

    // Users (Admin)
    getUsers() { return this.request('/users'); }
}

// Initialize global API instance
window.api = new FluxCRMAPI();
