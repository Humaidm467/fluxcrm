const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            imgSrc: ["'self'", "data:", "https://ui-avatars.com"],
            fontSrc: ["'self'", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com", "https://fonts.gstatic.com"],
            connectSrc: ["'self'", "http://localhost:*"],
        }
    }
}));

// CORS
const corsOptions = {
    origin: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
};
app.use(cors(corsOptions));

// Rate limiting
const limiter = rateLimit({
    windowMs: (parseInt(process.env.RATE_LIMIT_WINDOW) || 15) * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging
app.use(morgan(':method :url :status :res[content-length] - :response-time ms'));

// Compression
app.use(compression());

// Static files (frontend)
app.use(express.static('public'));

// In-memory data store (replace with database in production)
const db = {
    leads: [],
    contacts: [],
    opportunities: [],
    activities: [],
    quotes: [],
    orders: [],
    products: [],
    users: [
        { id: 1, name: 'Alex Morgan', email: 'alex@fluxcrm.com', role: 'Sales Director', password: '$2a$12$hashedpassword', active: true },
        { id: 2, name: 'Jordan Lee', email: 'jordan@fluxcrm.com', role: 'Account Executive', password: '$2a$12$hashedpassword', active: true }
    ],
    sessions: []
};

// Authentication middleware
const authenticate = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access denied. No token provided.' });

    try {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
        req.user = decoded;
        next();
    } catch (err) {
        res.status(400).json({ error: 'Invalid token.' });
    }
};

// Role-based access control
const authorize = (roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Access denied. Insufficient permissions.' });
        }
        next();
    };
};

// ==================== API ROUTES ====================

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString(), version: '1.0.0' });
});

// Auth routes
app.post('/api/auth/login', async (req, res) => {
    const bcrypt = require('bcryptjs');
    const jwt = require('jsonwebtoken');
    const { email, password } = req.body;

    const user = db.users.find(u => u.email === email && u.active);
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    // In production: const valid = await bcrypt.compare(password, user.password);
    const valid = true; // Demo mode

    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        process.env.JWT_SECRET || 'fallback-secret',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );

    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

app.get('/api/auth/me', authenticate, (req, res) => {
    const user = db.users.find(u => u.id === req.user.id);
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
});

// Leads API
app.get('/api/leads', authenticate, (req, res) => {
    res.json(db.leads);
});

app.post('/api/leads', authenticate, (req, res) => {
    const lead = { id: Date.now(), ...req.body, createdAt: new Date().toISOString() };
    db.leads.push(lead);
    res.status(201).json(lead);
});

app.put('/api/leads/:id', authenticate, (req, res) => {
    const idx = db.leads.findIndex(l => l.id === parseInt(req.params.id));
    if (idx === -1) return res.status(404).json({ error: 'Lead not found' });
    db.leads[idx] = { ...db.leads[idx], ...req.body, updatedAt: new Date().toISOString() };
    res.json(db.leads[idx]);
});

app.delete('/api/leads/:id', authenticate, (req, res) => {
    const idx = db.leads.findIndex(l => l.id === parseInt(req.params.id));
    if (idx === -1) return res.status(404).json({ error: 'Lead not found' });
    db.leads.splice(idx, 1);
    res.json({ message: 'Lead deleted' });
});

// Contacts API
app.get('/api/contacts', authenticate, (req, res) => {
    res.json(db.contacts);
});

app.post('/api/contacts', authenticate, (req, res) => {
    const contact = { id: Date.now(), ...req.body, createdAt: new Date().toISOString() };
    db.contacts.push(contact);
    res.status(201).json(contact);
});

// Opportunities API
app.get('/api/opportunities', authenticate, (req, res) => {
    res.json(db.opportunities);
});

app.post('/api/opportunities', authenticate, (req, res) => {
    const opp = { id: Date.now(), ...req.body, createdAt: new Date().toISOString() };
    db.opportunities.push(opp);
    res.status(201).json(opp);
});

app.put('/api/opportunities/:id', authenticate, (req, res) => {
    const idx = db.opportunities.findIndex(o => o.id === parseInt(req.params.id));
    if (idx === -1) return res.status(404).json({ error: 'Opportunity not found' });
    db.opportunities[idx] = { ...db.opportunities[idx], ...req.body, updatedAt: new Date().toISOString() };
    res.json(db.opportunities[idx]);
});

// Activities API
app.get('/api/activities', authenticate, (req, res) => {
    res.json(db.activities);
});

app.post('/api/activities', authenticate, (req, res) => {
    const activity = { id: Date.now(), ...req.body, createdAt: new Date().toISOString() };
    db.activities.push(activity);
    res.status(201).json(activity);
});

// Quotes API
app.get('/api/quotes', authenticate, (req, res) => {
    res.json(db.quotes);
});

app.post('/api/quotes', authenticate, (req, res) => {
    const quote = { id: `QT-${Date.now()}`, ...req.body, createdAt: new Date().toISOString() };
    db.quotes.push(quote);
    res.status(201).json(quote);
});

// Orders API
app.get('/api/orders', authenticate, (req, res) => {
    res.json(db.orders);
});

app.post('/api/orders', authenticate, (req, res) => {
    const order = { id: `SO-${Date.now()}`, ...req.body, createdAt: new Date().toISOString() };
    db.orders.push(order);
    res.status(201).json(order);
});

// Products API
app.get('/api/products', authenticate, (req, res) => {
    res.json(db.products);
});

app.post('/api/products', authenticate, authorize(['Sales Director', 'Admin']), (req, res) => {
    const product = { id: Date.now(), ...req.body, createdAt: new Date().toISOString() };
    db.products.push(product);
    res.status(201).json(product);
});

// Users API (Admin only)
app.get('/api/users', authenticate, authorize(['Sales Director', 'Admin']), (req, res) => {
    res.json(db.users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role, active: u.active })));
});

// Dashboard stats
app.get('/api/dashboard', authenticate, (req, res) => {
    const totalPipeline = db.opportunities.reduce((sum, o) => sum + (o.value || 0), 0);
    const weightedPipeline = db.opportunities.reduce((sum, o) => sum + ((o.value || 0) * (o.probability || 0) / 100), 0);
    const closedWon = db.opportunities.filter(o => o.stage === 'Closed Won').reduce((sum, o) => sum + (o.value || 0), 0);

    res.json({
        totalPipeline,
        weightedPipeline,
        closedWon,
        openDeals: db.opportunities.filter(o => o.stage !== 'Closed Won').length,
        totalLeads: db.leads.length,
        totalContacts: db.contacts.length,
        totalQuotes: db.quotes.length,
        totalOrders: db.orders.length,
        recentActivities: db.activities.slice(-5)
    });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 FluxCRM Server running on http://localhost:${PORT}`);
    console.log(`📊 API Documentation: http://localhost:${PORT}/api/health`);
    console.log(`🔒 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
